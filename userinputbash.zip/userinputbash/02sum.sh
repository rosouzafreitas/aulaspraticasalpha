a=15
b=25
((sum=a+b))
echo $sum
